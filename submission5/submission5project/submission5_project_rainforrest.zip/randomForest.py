import numpy as np
import cv2
import os
import random
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report
from sklearn.ensemble import RandomForestClassifier
from mlxtend.plotting import plot_decision_regions

print('----------------')
print('Creating model !')
print('----------------')


DIRECTORY = r"./"
CATAGORIES = ["diseased","healthy"]

data = []

for cata in CATAGORIES:
  folder = os.path.join(DIRECTORY,cata)
  label = CATAGORIES.index(cata)

  for img in os.listdir(folder):
    img = os.path.join(folder,img)
    img_arr = cv2.imread(img)
    img_arr = cv2.resize(img_arr,(100,100))
    data.append([img_arr,label])
    random.shuffle(data)

x = []
y = []

for feature, label in data:
  x.append(feature)
  y.append(label)

x = np.array(x)
y = np.array(y)
x = x/255

nsamples, nx, ny, nrgb = x.shape
x = x.reshape((nsamples,nx*ny*nrgb))

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1, random_state=1, stratify=y)

# nsamples, nx, ny, nrgb = x_train.shape
# x_train2 = x_train.reshape((nsamples,nx*ny*nrgb))

# nsamples, nx, ny, nrgb = x_test.shape
# x_test2 = x_test.reshape((nsamples,nx*ny*nrgb))

forest = RandomForestClassifier(criterion='gini',n_estimators=5,random_state=1,n_jobs=2)


forest.fit(x_train, y_train)

y_pred = forest.predict(x_test)

print('--------------')
print('Accuracy Score')
print('--------------')

accuracy_score(y_pred,y_test)
print(classification_report(y_pred,y_test))

print('----------------')
print('Confusion Matrix')
print('----------------')

print(confusion_matrix(y_pred,y_test))

print('-----------')
print('Custom Test')
print('-----------')

img_path='./heal (3).jpeg'
img_arr=cv2.imread(img_path)
img_arr=cv2.resize(img_arr,(100,100))

nx, ny, nrgb = img_arr.shape
img_arr2 = img_arr.reshape(1,(nx*ny*nrgb))

classes = ["Diseaded","Healthy"]
ans=forest.predict(img_arr2)
print("The flower is " + classes[ans[0]])


